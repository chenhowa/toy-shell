To compile the program, enter the command "make" in the command line. The resulting executable will be called "smallsh". To run it, enter "./smallsh"

Enter "make clean" to the command line to restore the directory to its original state.
